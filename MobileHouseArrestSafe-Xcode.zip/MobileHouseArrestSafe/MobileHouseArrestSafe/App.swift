import SwiftUI

@main
struct MobileHouseArrestSafeApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
